-- 변수 할당 (init과 통일)
DEFINE NEW_USER = 'devuser';
DEFINE NEW_SPACE = 'DEV_SPACE'

CREATE TABLE &NEW_USER..MHS_USR (
  usr_id varchar2(30) NOT NULL,
  passwd varchar2(100) NOT NULL,
  tmp_passwd_yn char(1) DEFAULT 'N',
  passwd_chg_dtm date DEFAULT NULL,
  usr_nm varchar2(30) NOT NULL,
  nck_nm varchar2(30) DEFAULT NULL,
  sex_cd varchar2(20) DEFAULT NULL,
  birth_dt date DEFAULT NULL,
  eml varchar2(50) DEFAULT NULL,
  sf_intrdct varchar2(200) DEFAULT NULL,
  usr_mob varchar2(20) NOT NULL,
  lgn_cnt number DEFAULT 0,
  ntv_yn char(1) DEFAULT 'N',
  lst_lgn_dtm date DEFAULT NULL,
  lst_con_ip varchar2(15) DEFAULT NULL,
  prvs_agr_yn char(1) DEFAULT 'N',
  push_key varchar2(255) DEFAULT NULL,
  evt_agr_yn char(1) DEFAULT 'Y',
  alm_agr_yn char(1) DEFAULT 'Y',
  mkt_agr_yn char(1) DEFAULT 'N',
  loc_info_agr_yn char(1) DEFAULT 'N',
  ntc_alm_agr_yn char(1) DEFAULT 'Y',
  prim_schd_alm_yn char(1) DEFAULT 'Y',
  ci varchar2(100) DEFAULT NULL,
  org_fle_nm varchar2(255) DEFAULT NULL,
  sv_fle_nm varchar2(255) DEFAULT NULL,
  fle_path varchar2(500) DEFAULT NULL,
  use_yn char(1) DEFAULT 'Y',
  del_yn char(1) DEFAULT 'N' NOT NULL,
  reg_id varchar2(100) DEFAULT NULL,
  reg_dtm date DEFAULT SYSDATE,
  mod_id varchar2(100) DEFAULT NULL ,
  mod_dtm date DEFAULT SYSDATE
) TABLESPACE &NEW_SPACE;

COMMENT ON TABLE &NEW_USER..MHS_USR IS '일반 사용자';
COMMENT ON COLUMN &NEW_USER..MHS_USR.usr_id IS '사용자아이디';
COMMENT ON COLUMN &NEW_USER..MHS_USR.passwd IS '비밀번호';
COMMENT ON COLUMN &NEW_USER..MHS_USR.tmp_passwd_yn IS '임시비밀번호여부';
COMMENT ON COLUMN &NEW_USER..MHS_USR.passwd_chg_dtm IS '비밀번호변경일';
COMMENT ON COLUMN &NEW_USER..MHS_USR.usr_nm IS '사용자명';
COMMENT ON COLUMN &NEW_USER..MHS_USR.nck_nm IS '별명';
COMMENT ON COLUMN &NEW_USER..MHS_USR.sex_cd IS '성별';
COMMENT ON COLUMN &NEW_USER..MHS_USR.birth_dt IS '생년월일';
COMMENT ON COLUMN &NEW_USER..MHS_USR.eml IS '이메일';
COMMENT ON COLUMN &NEW_USER..MHS_USR.sf_intrdct IS '자기소개';
COMMENT ON COLUMN &NEW_USER..MHS_USR.usr_mob IS '휴대전화';
COMMENT ON COLUMN &NEW_USER..MHS_USR.lgn_cnt IS '로그인횟수';
COMMENT ON COLUMN &NEW_USER..MHS_USR.ntv_yn IS '내외국인구분';
COMMENT ON COLUMN &NEW_USER..MHS_USR.lst_lgn_dtm IS '마지막 접속일';
COMMENT ON COLUMN &NEW_USER..MHS_USR.lst_con_ip IS '마지막 접속IP';
COMMENT ON COLUMN &NEW_USER..MHS_USR.prvs_agr_yn IS '이용약관동의여부';
COMMENT ON COLUMN &NEW_USER..MHS_USR.push_key IS '파이어베이스키';
COMMENT ON COLUMN &NEW_USER..MHS_USR.evt_agr_yn IS '게시글알림동의';
COMMENT ON COLUMN &NEW_USER..MHS_USR.alm_agr_yn IS '서비스알림동의';
COMMENT ON COLUMN &NEW_USER..MHS_USR.mkt_agr_yn IS '마케팅 정보 수집 동의';
COMMENT ON COLUMN &NEW_USER..MHS_USR.loc_info_agr_yn IS '위치정보 수집 동의';
COMMENT ON COLUMN &NEW_USER..MHS_USR.ntc_alm_agr_yn IS '공지알림동의여부';
COMMENT ON COLUMN &NEW_USER..MHS_USR.prim_schd_alm_yn IS '주요일정알림여부';
COMMENT ON COLUMN &NEW_USER..MHS_USR.ci IS 'ci';
COMMENT ON COLUMN &NEW_USER..MHS_USR.org_fle_nm IS '실제파일명';
COMMENT ON COLUMN &NEW_USER..MHS_USR.sv_fle_nm IS '물리파일명';
COMMENT ON COLUMN &NEW_USER..MHS_USR.fle_path IS '파일위치';
COMMENT ON COLUMN &NEW_USER..MHS_USR.use_yn IS '사용여부';
COMMENT ON COLUMN &NEW_USER..MHS_USR.del_yn IS '삭제여부';
COMMENT ON COLUMN &NEW_USER..MHS_USR.reg_id IS '등록자';
COMMENT ON COLUMN &NEW_USER..MHS_USR.reg_dtm IS '등록일';
COMMENT ON COLUMN &NEW_USER..MHS_USR.mod_id IS '수정자';
COMMENT ON COLUMN &NEW_USER..MHS_USR.mod_dtm IS '수정일';